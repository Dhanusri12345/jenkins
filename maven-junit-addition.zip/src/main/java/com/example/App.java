package com.example;

public class App {
    public static int add(int a, int b) {
        return a + b;
    }
}
